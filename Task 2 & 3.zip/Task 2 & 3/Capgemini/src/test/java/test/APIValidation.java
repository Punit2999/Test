package test;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;
public class APIValidation 

{
static String id;
	
@Test(priority=1)
public static void createBoard()
{
RestAssured.baseURI="https://api.trello.com";


String response=given().log().all().queryParam("name", "TestBoard123").queryParam("token", "eb39aa13daa95ca97cdfa091b0f440208dab849c240674b34306bc37cf3a8394")
.queryParam("key", "eeee67b66738c34c431c2ad1352469ba").headers("Content-Type","text/plain").when().post("1/boards").then().log()
.all().assertThat().statusCode(200).extract().asString();

JsonPath js=new JsonPath(response);
id = js.get("id");
System.out.println(id);

}

@Test(priority=2)
public void createList()
{
	RestAssured.baseURI="https://api.trello.com";
	given().log().all().queryParam("name", "FirstList").queryParam("idBoard",id )
	.queryParam("token", "eb39aa13daa95ca97cdfa091b0f440208dab849c240674b34306bc37cf3a8394")
	.queryParam("key", "eeee67b66738c34c431c2ad1352469ba").headers("Content-Type","text/plain").when().post("1/lists").then()
	.log().all().assertThat().statusCode(200);
}

@Test(priority=3)
public void validateStatus200()
{
	RestAssured.baseURI="https://api.trello.com";
	given().log().all().queryParam("token", "eb39aa13daa95ca97cdfa091b0f440208dab849c240674b34306bc37cf3a8394")
	.queryParam("key", "eeee67b66738c34c431c2ad1352469ba").headers("Content-Type","text/plain").headers("Accept","application/json").when().get("1/boards/"+id).then()
	.log().all().assertThat().statusCode(200);	
}

@Test(priority=4)
public void validateStatus400()
{
	RestAssured.baseURI="https://api.trello.com";
	given().log().all().queryParam("name", "").queryParam("token", "eb39aa13daa95ca97cdfa091b0f440208dab849c240674b34306bc37cf3a8394")
			.queryParam("key", "eeee67b66738c34c431c2ad1352469ba").headers("Content-Type","text/plain").when().post("1/boards").then().log()
			.all().assertThat().statusCode(400);
}


@Test(priority=5)
public void deleteBoard()
{
	RestAssured.baseURI="https://api.trello.com";
	given().log().all().queryParam("token", "eb39aa13daa95ca97cdfa091b0f440208dab849c240674b34306bc37cf3a8394")
	.queryParam("key", "eeee67b66738c34c431c2ad1352469ba").headers("Content-Type","text/plain").when().delete("1/boards/"+id).then()
	.log().all().assertThat().statusCode(200);	
}

	
}
