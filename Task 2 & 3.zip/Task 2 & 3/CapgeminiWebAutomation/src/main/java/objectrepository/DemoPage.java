package objectrepository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DemoPage 
{
	public WebDriver driver;
	
	By scrollToBottom=By.xpath("//footer[@class='topic-list-bottom']");
	By closeTopic=By.xpath("//span[@title='This topic is closed; it no longer accepts new replies']/parent::div/following-sibling::a");
	By numberOfCategory=By.xpath("//span[@class='category-name']");
	By numberOfViews=By.xpath("//tbody/tr/td[contains(@class,'num views ')]/span");
	By title=By.xpath("//tbody/tr/td[contains(@class,'num views ')]/preceding-sibling::td[@class='main-link clearfix']/span/a");
	
public DemoPage(WebDriver driver)
{
	this.driver=driver;
}
	
	public WebElement scrollToBottom()
	{
		return driver.findElement(scrollToBottom);
	}
	
	public List<WebElement> printCloseTopic()
	{
		return driver.findElements(closeTopic);
	}
	
	public List<WebElement> maxnumberOfViews()
	{
		return driver.findElements(numberOfViews);
	}
	
	public List<WebElement> title()
	{
		return driver.findElements(title);
	}
	
	public List<WebElement> category()
	{
		return driver.findElements(numberOfCategory);
	}
}
