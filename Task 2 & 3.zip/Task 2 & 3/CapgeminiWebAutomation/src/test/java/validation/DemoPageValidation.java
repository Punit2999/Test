package validation;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Iterator;


import org.apache.logging.log4j.*;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import objectrepository.DemoPage;
import objectrepository.HomePage;
import resources.BaseClass;

public class DemoPageValidation extends BaseClass {

	public WebDriver driver;
	DemoPage dp;

	public static Logger log = LogManager.getLogger(BaseClass.class.getName());

	@BeforeTest
	public void setUP() throws IOException, AWTException {
		driver = initializeBrowser();
		log.info("driver initialize");
		driver.get(prop.getProperty("url"));
		log.info("navigate to URL");
	}

	@Test(priority = 1)
	public void clickDemoOption() {
		HomePage hp = new HomePage(driver);
		hp.clickDemoButton().click();

	}

	@Test(priority = 2)
	public void scrollToBottom() throws InterruptedException {
		Iterator<String> b = driver.getWindowHandles().iterator();
		while (b.hasNext()) {
			String a = b.next();
			driver.switchTo().window(a);
			if (driver.getTitle().equals("Demo")) {
				break;
			}
		}
		dp = new DemoPage(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		long firstHeight = (Long) js.executeScript("return document.body.scrollHeight");
		while (true) {
			js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
			Thread.sleep(2000);
			long newHeight = (Long) js.executeScript("return document.body.scrollHeight");
			if (newHeight == firstHeight) {
				break;
			}
			firstHeight = newHeight;
		}
		String actualText=dp.scrollToBottom().getText();
		String expectedText="There are no more latest topics.";
		Assert.assertEquals(actualText, expectedText);	
		
	}

	@Test(priority = 3)
	public void printCloseCategory() {
		dp = new DemoPage(driver);
		int i = dp.printCloseTopic().size();
		System.out.println("===============================================");
		for (int j = 0; j < i; j++) {
			System.out.println("Closed Topics: " + dp.printCloseTopic().get(j).getText());
		}
		System.out.println("===============================================");
	}

	@Test(priority = 4)
	public void categoryCount() {
		int uncategorizedTopics = dp.maxnumberOfViews().size() - dp.category().size();
		System.out.println("===============================================");
		System.out.println("Uncategozied Topics: " + uncategorizedTopics);
		int categorySize = dp.category().size();
		System.out.println("Categorized Topics: " + categorySize);
		System.out.println("===============================================");
		String[] categoryArray = new String[categorySize];
		String[] distinctArray = new String[categorySize];
		
		for (int i = 0; i < categorySize; i++) {
			categoryArray[i] = dp.category().get(i).getText();
		}
		int index = 0;
		for (int i = 0; i < categorySize; i++) {
			int flag = 0;
			for (int j = 0; j < i; j++) {
				if (categoryArray[i].equals(categoryArray[j])) {
					flag = 1;
					break;				}
			}
			if (flag == 0) {
				distinctArray[index] = categoryArray[i];
				index++;
			}
		}
		System.out.println("===============================================");
			
		for(int i=0;i<index;i++)
		{
			int res=0;
			for(int j=0;j<categorySize;j++)
			{
				if(distinctArray[i].equals(categoryArray[j]))
				{
					res++;
				}
			}
			System.out.println("Category: " + distinctArray[i] + ", Count: " + res);
		}
		System.out.println("===============================================");
	}
	
	

	@Test(priority = 5)
	public void maxNumberOfViews() {
		int size = dp.maxnumberOfViews().size();
		String title = null;
		int k = 0;
		
		for (int i = 0; i < size; i++) {
			String number = dp.maxnumberOfViews().get(i).getAttribute("title");
			int sizeOfString=number.length();
			String number1 = number.substring(27, sizeOfString);
			String[] number2 = number1.split(" ");
			int j = Integer.parseInt(number2[0].replaceAll(",", ""));

			if (j >= k) 
			
			{
				k = j;
				title = dp.title().get(i).getText();
			}

		}
		System.out.println("===============================================");
		System.out.println("Most Viewed Course: "+ title);
		System.out.println("===============================================");

	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}
